This folder has our summer photos!!
We love vacations